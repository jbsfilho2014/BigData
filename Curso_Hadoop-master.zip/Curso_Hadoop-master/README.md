
# Tutorial Hadoop
Descrição: Repositório de arquivos e códigos usados no tutorial de hadoop map-reduce do blog: http://www.codigofluente.com.br

## Pré-requisitos
* Máquina Cloudera
    * Link para o download da máquina: https://www.cloudera.com/downloads/quickstart_vms/5-13.html
* Putty
    * Link para o download do putty: https://www.putty.org/
* WINSCP
    * Link para o download do WINSCP: https://winscp.net/eng/download.php

### Configuração da máquina Cloudera
Para detalhes de como configurar a máquina cloudera acesse: http://www.codigofluente.com.br/configuracao-da-maquina-cloudera/


# Hadoop Tutorial
description: Repository of files and codes used in the hadoop map-reduce tutorial, content of the blog: http://www.codigofluente.com.br

## Prerequisites
* Cloudera machine
    * Link to download cloudera machine: https://www.cloudera.com/downloads/quickstart_vms/5-13.html
* Putty
    * Link to putty download: https://www.putty.org/
* WINSCP
    * Link to WINSCP download: https://winscp.net/eng/download.php

### Cloudera Machine configuration
For details on how to configure the cloudera machine, go to: http://www.codigofluente.com.br/configuracao-da-maquina-cloudera/
